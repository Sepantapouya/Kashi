# Third-party icon artwork

Kashi's original code and UI drawings are MIT licensed. Brand and cryptocurrency artwork is adapted from Simple Icons (16.37.0, 13.21.0 and 11.15.0) and Web3 Icons (4.0.59; metadata 0.11.54). The per-icon source, upstream license and adaptation notes are recorded in [brand-sources.json](./brand-sources.json). Original brand marks and names remain associated with their respective owners; inclusion does not imply endorsement.

Coordinate normalization, the documented standalone lettering adaptation and monochrome palette projection are applied. Brand artwork preserves its own geometry across all Kashi style options.

## Simple Icons collection — CC0 1.0

Upstream: https://github.com/simple-icons/simple-icons

# CC0 1.0 Universal

## Statement of Purpose

The laws of most jurisdictions throughout the world automatically confer exclusive Copyright and Related Rights (defined below) upon the creator and subsequent owner(s) (each and all, an “owner”) of an original work of authorship and/or a database (each, a “Work”).

Certain owners wish to permanently relinquish those rights to a Work for the purpose of contributing to a commons of creative, cultural and scientific works (“Commons”) that the public can reliably and without fear of later claims of infringement build upon, modify, incorporate in other works, reuse and redistribute as freely as possible in any form whatsoever and for any purposes, including without limitation commercial purposes. These owners may contribute to the Commons to promote the ideal of a free culture and the further production of creative, cultural and scientific works, or to gain reputation or greater distribution for their Work in part through the use and efforts of others.

For these and/or other purposes and motivations, and without any expectation of additional consideration or compensation, the person associating CC0 with a Work (the “Affirmer”), to the extent that he or she is an owner of Copyright and Related Rights in the Work, voluntarily elects to apply CC0 to the Work and publicly distribute the Work under its terms, with knowledge of his or her Copyright and Related Rights in the Work and the meaning and intended legal effect of CC0 on those rights.

1. Copyright and Related Rights. A Work made available under CC0 may be protected by copyright and related or neighboring rights (“Copyright and Related Rights”). Copyright and Related Rights include, but are not limited to, the following:
    1. the right to reproduce, adapt, distribute, perform, display, communicate, and translate a Work;
    2. moral rights retained by the original author(s) and/or performer(s);
    3. publicity and privacy rights pertaining to a person’s image or likeness depicted in a Work;
    4. rights protecting against unfair competition in regards to a Work, subject to the limitations in paragraph 4(i), below;
    5. rights protecting the extraction, dissemination, use and reuse of data in a Work;
    6. database rights (such as those arising under Directive 96/9/EC of the European Parliament and of the Council of 11 March 1996 on the legal protection of databases, and under any national implementation thereof, including any amended or successor version of such directive); and
    7. other similar, equivalent or corresponding rights throughout the world based on applicable law or treaty, and any national implementations thereof.

2. Waiver. To the greatest extent permitted by, but not in contravention of, applicable law, Affirmer hereby overtly, fully, permanently, irrevocably and unconditionally waives, abandons, and surrenders all of Affirmer’s Copyright and Related Rights and associated claims and causes of action, whether now known or unknown (including existing as well as future claims and causes of action), in the Work (i) in all territories worldwide, (ii) for the maximum duration provided by applicable law or treaty (including future time extensions), (iii) in any current or future medium and for any number of copies, and (iv) for any purpose whatsoever, including without limitation commercial, advertising or promotional purposes (the “Waiver”). Affirmer makes the Waiver for the benefit of each member of the public at large and to the detriment of Affirmer’s heirs and successors, fully intending that such Waiver shall not be subject to revocation, rescission, cancellation, termination, or any other legal or equitable action to disrupt the quiet enjoyment of the Work by the public as contemplated by Affirmer’s express Statement of Purpose.

3. Public License Fallback. Should any part of the Waiver for any reason be judged legally invalid or ineffective under applicable law, then the Waiver shall be preserved to the maximum extent permitted taking into account Affirmer’s express Statement of Purpose. In addition, to the extent the Waiver is so judged Affirmer hereby grants to each affected person a royalty-free, non transferable, non sublicensable, non exclusive, irrevocable and unconditional license to exercise Affirmer’s Copyright and Related Rights in the Work (i) in all territories worldwide, (ii) for the maximum duration provided by applicable law or treaty (including future time extensions), (iii) in any current or future medium and for any number of copies, and (iv) for any purpose whatsoever, including without limitation commercial, advertising or promotional purposes (the “License”). The License shall be deemed effective as of the date CC0 was applied by Affirmer to the Work. Should any part of the License for any reason be judged legally invalid or ineffective under applicable law, such partial invalidity or ineffectiveness shall not invalidate the remainder of the License, and in such case Affirmer hereby affirms that he or she will not (i) exercise any of his or her remaining Copyright and Related Rights in the Work or (ii) assert any associated claims and causes of action with respect to the Work, in either case contrary to Affirmer’s express Statement of Purpose.

4. Limitations and Disclaimers.
    1. No trademark or patent rights held by Affirmer are waived, abandoned, surrendered, licensed or otherwise affected by this document.
    2. Affirmer offers the Work as-is and makes no representations or warranties of any kind concerning the Work, express, implied, statutory or otherwise, including without limitation warranties of title, merchantability, fitness for a particular purpose, non infringement, or the absence of latent or other defects, accuracy, or the present or absence of errors, whether or not discoverable, all to the greatest extent permissible under applicable law.
    3. Affirmer disclaims responsibility for clearing rights of other persons that may apply to the Work or any use thereof, including without limitation any person’s Copyright and Related Rights in the Work. Further, Affirmer disclaims responsibility for obtaining any necessary consents, permissions or other rights required for any use of the Work.
    4. Affirmer understands and acknowledges that Creative Commons is not a party to this document and has no duty or obligation with respect to this CC0 or use of the Work.

For more information, please see <https://creativecommons.org/publicdomain/zero/1.0>.


## Web3 Icons — MIT

Upstream: https://github.com/0xa3k5/web3icons

MIT License

Copyright (c) 2024 0xa3k5

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Individual artwork licenses

The collection-level CC0 dedication does not override individual artwork licenses. Each mark retains its listed license, attribution, source and any share-alike terms in `brand-sources.json`; the corresponding SVG contains a source/license notice. Normalization of coordinates and the documented lettering crop are the only artwork adaptations. Artwork with custom licensing terms is excluded from this public batch.

## Persian Labs Icons — MIT

200 additional Iranian marks use the mono artwork from `@persianlabs/icons` 1.0.4, pinned to commit c4db29f43a1ebaa0bfc1890a6bc64745457bc03f.

MIT License

Copyright (c) 2026 Persian Labs contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

Brand artwork uses currentColor. Four multicolor wallet marks are projected through inverse-luminance masks to retain their contrast and negative spaces in the selected color.

## Vazirmatn — SIL Open Font License 1.1

The 86 Persian letter and numeral icons use outlines extracted from Vazirmatn 33.003, at weights 500 and 700. Copyright 2015 The Vazirmatn Project Authors (https://github.com/rastikerdar/vazirmatn). Coordinates are fitted to the icon grid; no runtime font loading is required. The existing hollow-zero variant retains its outlined presentation. Source font checksum, character mapping and glyph IDs are recorded in `audits/vazirmatn-glyphs.json`. The full font license is distributed in `Vazirmatn-OFL.txt`.

## Tabler and Iconoir — MIT

The 800 general-purpose additions in `general-sources.json` are adapted from Tabler Icons 3.52.0 and Iconoir 7.12.2 (commit 39834e3f193bc0cca2c36bebb6a650471977433d). They are upstream-authored drawings adapted to Kashi, rather than newly authored original Kashi artwork. They contain no new bank or brand marks.

Tabler: Copyright (c) 2020–2026 Paweł Kuna. The full license is distributed in `Tabler-MIT.txt`.

Iconoir: Copyright (c) 2021 Luca Burgio. The full license is distributed in `Iconoir-MIT.txt`.

The source manifest records the original file, pinned version or revision, original SVG checksums and normalized body checksum for every drawing. Coordinates are fitted to the 20×20 grid, strokes use the 1.5 reference weight, and rectangle elements use Kashi's continuous corners. Where available, upstream filled artwork is used for the bold variant. Non-rendering clip definitions are excluded from visible geometry; actual source fill and stroke instructions and even-odd holes are preserved.

## Hugeicons 4.4.0 — MIT

801 general drawings are adapted from @hugeicons/core-free-icons 4.4.0. Copyright © 2025 Hugeicons. The full license accompanies this package in Hugeicons-MIT.txt. File-specific source URLs and checksums are in general-sources.json.

## Natural Earth 5.1.1 — public domain

168 country silhouettes and 31 Iranian province silhouettes are simplified from Natural Earth admin-0/admin-1 data. Scope, source feature identity, projection and geometry adaptations are recorded in general-sources.json. See Natural-Earth-PUBLIC-DOMAIN.txt.
